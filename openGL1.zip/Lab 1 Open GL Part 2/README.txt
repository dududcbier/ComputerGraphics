This program renders images from model objects. This version of the program supports spheres. 
Spheres are build with triangles. 

The material colour, lightposition, lightcolour and position of the spere are used to place
speres properly in an rendered image. Unfortunately there is a bug in this part of the program.
Making us unable to continue an implement the phong shading that should be in this program.