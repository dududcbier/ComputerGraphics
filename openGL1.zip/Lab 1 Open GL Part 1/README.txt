This program renders images from model objects. This version of the program supports cubes. 
Cubes are build with triangles. 
Each triangle of which the cube exists is assigned a randomly generated colour. 
(No colours are defined in the object files.)

The output of this program is an interactive image. Scrolling allows the user to 
zoom and moving the mouse wile pressing a mouse button enables the user to rotate the image.